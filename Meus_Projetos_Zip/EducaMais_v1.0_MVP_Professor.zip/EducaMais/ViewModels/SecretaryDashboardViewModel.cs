using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EducaMais.Services;
using EducaMais.Models;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text.Json;
using System.Linq;

namespace EducaMais.ViewModels;

public partial class SecretaryDashboardViewModel : ViewModelBase
{
    [ObservableProperty]
    private string _tenantName = "Carregando...";

    [ObservableProperty]
    private bool _isVisaoGeralVisible = true;

    [ObservableProperty]
    private bool _isEscolasVisible = false;

    [ObservableProperty]
    private bool _isDiretoresVisible = false;

    [ObservableProperty]
    private bool _isRelatoriosVisible = false;

    [ObservableProperty]
    private bool _isSchoolModalOpen = false;

    [ObservableProperty]
    private string _modalTitle = "Adicionar Escola";

    [ObservableProperty]
    private School _editingSchool = new();

    public ObservableCollection<School> Schools { get; set; } = new();

    // --- DIRECTORS ---
    [ObservableProperty]
    private bool _isDirectorModalOpen = false;

    [ObservableProperty]
    private string _directorModalTitle = "Adicionar Diretor";

    [ObservableProperty]
    private Director _editingDirector = new();

    public ObservableCollection<Director> Directors { get; set; } = new();

    public System.Action? OnLogout { get; set; }
    public System.Action<School>? OnAccessSchool { get; set; }

    [RelayCommand]
    private void Navigate(string viewName)
    {
        IsVisaoGeralVisible = viewName == "VisaoGeral";
        IsEscolasVisible = viewName == "Escolas";
        IsDiretoresVisible = viewName == "Diretores";
        IsRelatoriosVisible = viewName == "Relatorios";

        if (viewName == "Escolas")
        {
            _ = LoadSchoolsAsync();
        }
        else if (viewName == "Diretores")
        {
            // Precisamos carregar as escolas primeiro para o ComboBox do modal
            _ = LoadSchoolsAsync().ContinueWith(_ => LoadDirectorsAsync());
        }
    }

    public SecretaryDashboardViewModel()
    {
    }

    partial void OnTenantNameChanged(string value)
    {
        _ = LoadSchoolsAsync();
    }

    private async Task LoadSchoolsAsync()
    {
        if (string.IsNullOrWhiteSpace(TenantName) || TenantName == "Carregando...") return;

        try
        {
            var queryJson = "{\"method\":\"equal\",\"attribute\":\"tenant_id\",\"values\":[\"" + TenantName + "\"]}";
            var queries = new List<string> { queryJson };

            var res = await AppwriteService.Instance.RawListDocumentsAsync("schools", queries);
            var docs = res.GetProperty("documents");
            
            Schools.Clear();
            foreach (var doc in docs.EnumerateArray())
            {
                var school = new School
                {
                    Id = doc.GetProperty("$id").GetString() ?? "",
                    Name = doc.TryGetProperty("name", out var nProp) && nProp.ValueKind != JsonValueKind.Null ? nProp.GetString() ?? "" : "",
                    Inep = doc.TryGetProperty("inep", out var iProp) && iProp.ValueKind != JsonValueKind.Null ? iProp.GetString() ?? "" : "",
                    Principal = doc.TryGetProperty("principal", out var pProp) && pProp.ValueKind != JsonValueKind.Null ? pProp.GetString() ?? "" : "",
                    TenantId = doc.TryGetProperty("tenant_id", out var tProp) && tProp.ValueKind != JsonValueKind.Null ? tProp.GetString() ?? "" : "",
                    Status = doc.TryGetProperty("status", out var sProp) && sProp.ValueKind != JsonValueKind.Null ? sProp.GetString() ?? "Ativa" : "Ativa"
                };
                Schools.Add(school);
            }
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao carregar escolas: " + ex.Message);
        }
    }

    [RelayCommand]
    private void OpenAddSchoolModal()
    {
        EditingSchool = new School { TenantId = TenantName };
        ModalTitle = "Adicionar Escola";
        IsSchoolModalOpen = true;
    }

    
    [RelayCommand]
    private void AccessSchool(School school)
    {
        OnAccessSchool?.Invoke(school);
    }
    
    [RelayCommand]
    private void EditSchool(School school)

    {
        EditingSchool = new School
        {
            Id = school.Id,
            Name = school.Name,
            Inep = school.Inep,
            Principal = school.Principal,
            TenantId = school.TenantId,
            Status = school.Status
        };
        ModalTitle = "Editar Escola";
        IsSchoolModalOpen = true;
    }

    [RelayCommand]
    private void CloseModal()
    {
        IsSchoolModalOpen = false;
    }

    [RelayCommand]
    private async Task SaveSchoolAsync()
    {
        if (string.IsNullOrWhiteSpace(EditingSchool.Name)) return;

        try
        {
            var data = new Dictionary<string, object>
            {
                { "name", EditingSchool.Name },
                { "inep", EditingSchool.Inep },
                { "principal", EditingSchool.Principal },
                { "tenant_id", TenantName },
                { "status", EditingSchool.Status }
            };

            if (string.IsNullOrEmpty(EditingSchool.Id))
            {
                await AppwriteService.Instance.RawCreateDocumentAsync("schools", data, new List<string> { "read(\"any\")", "update(\"users\")", "delete(\"users\")" });
            }
            else
            {
                await AppwriteService.Instance.RawUpdateDocumentAsync("schools", EditingSchool.Id, data);
            }

            IsSchoolModalOpen = false;
            await LoadSchoolsAsync();
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao salvar escola: " + ex.Message);
        }
    }

    [RelayCommand]
    private async Task DeleteSchoolAsync(School school)
    {
        try
        {
            await AppwriteService.Instance.RawDeleteDocumentAsync("schools", school.Id);
            await LoadSchoolsAsync();
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao excluir escola: " + ex.Message);
        }
    }

    // --- DIRETORES CRUD ---

    private async Task LoadDirectorsAsync()
    {
        if (string.IsNullOrWhiteSpace(TenantName) || TenantName == "Carregando...") return;

        try
        {
            var queryJson = "{\"method\":\"equal\",\"attribute\":\"tenant_id\",\"values\":[\"" + TenantName + "\"]}";
            var queries = new List<string> { queryJson };

            var res = await AppwriteService.Instance.RawListDocumentsAsync("directors", queries);
            var docs = res.GetProperty("documents");
            
            // Para poder manipular em UI thread segura
            var newDirectors = new List<Director>();

            foreach (var doc in docs.EnumerateArray())
            {
                var dir = new Director
                {
                    Id = doc.GetProperty("$id").GetString() ?? "",
                    Name = doc.TryGetProperty("name", out var nProp) && nProp.ValueKind != JsonValueKind.Null ? nProp.GetString() ?? "" : "",
                    Email = doc.TryGetProperty("email", out var eProp) && eProp.ValueKind != JsonValueKind.Null ? eProp.GetString() ?? "" : "",
                    Phone = doc.TryGetProperty("phone", out var pProp) && pProp.ValueKind != JsonValueKind.Null ? pProp.GetString() ?? "" : "",
                    SchoolId = doc.TryGetProperty("school_id", out var sProp) && sProp.ValueKind != JsonValueKind.Null ? sProp.GetString() ?? "" : "",
                    TenantId = doc.TryGetProperty("tenant_id", out var tProp) && tProp.ValueKind != JsonValueKind.Null ? tProp.GetString() ?? "" : "",
                };

                var matchingSchool = Schools.FirstOrDefault(s => s.Id == dir.SchoolId);
                dir.SchoolName = matchingSchool != null ? matchingSchool.Name : "Sem vínculo";

                newDirectors.Add(dir);
            }

            Avalonia.Threading.Dispatcher.UIThread.Post(() => {
                Directors.Clear();
                foreach(var d in newDirectors) Directors.Add(d);
            });
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao carregar diretores: " + ex.Message);
        }
    }

    [RelayCommand]
    private void OpenAddDirectorModal()
    {
        EditingDirector = new Director { TenantId = TenantName };
        DirectorModalTitle = "Adicionar Diretor";
        IsDirectorModalOpen = true;
    }

    [RelayCommand]
    private void EditDirector(Director dir)
    {
        EditingDirector = new Director
        {
            Id = dir.Id,
            Name = dir.Name,
            Email = dir.Email,
            Phone = dir.Phone,
            SchoolId = dir.SchoolId,
            TenantId = dir.TenantId
        };
        DirectorModalTitle = "Editar Diretor";
        IsDirectorModalOpen = true;
    }

    [RelayCommand]
    private void CloseDirectorModal()
    {
        IsDirectorModalOpen = false;
    }

    [RelayCommand]
    private async Task SaveDirectorAsync()
    {
        if (string.IsNullOrWhiteSpace(EditingDirector.Name)) return;

        try
        {
            var data = new Dictionary<string, object>
            {
                { "name", EditingDirector.Name },
                { "email", EditingDirector.Email },
                { "phone", EditingDirector.Phone },
                { "school_id", EditingDirector.SchoolId },
                { "tenant_id", TenantName }
            };

            if (string.IsNullOrEmpty(EditingDirector.Id))
            {
                await AppwriteService.Instance.RawCreateDocumentAsync("directors", data, new List<string> { "read(\"any\")", "update(\"users\")", "delete(\"users\")" });
            }
            else
            {
                await AppwriteService.Instance.RawUpdateDocumentAsync("directors", EditingDirector.Id, data);
            }

            IsDirectorModalOpen = false;
            await LoadDirectorsAsync();
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao salvar diretor: " + ex.Message);
        }
    }

    [RelayCommand]
    private async Task DeleteDirectorAsync(Director dir)
    {
        try
        {
            await AppwriteService.Instance.RawDeleteDocumentAsync("directors", dir.Id);
            await LoadDirectorsAsync();
        }
        catch (System.Exception ex)
        {
            System.Console.WriteLine("Erro ao excluir diretor: " + ex.Message);
        }
    }

    
    // --- RELATÓRIOS ---
    [ObservableProperty]
    private School? _selectedReportSchool;

    [ObservableProperty]
    private string _reportTitle = "Relatório Global da Rede";

    [ObservableProperty]
    private string _frequenciaMedia = "92.5%";

    [ObservableProperty]
    private int _bim1Height = 90;

    [ObservableProperty]
    private int _bim2Height = 120;

    [ObservableProperty]
    private int _bim3Height = 100;

    [ObservableProperty]
    private int _bim4Height = 140;

    [RelayCommand]
    private void SetSelectedReportSchoolNull()
    {
        SelectedReportSchool = null;
    }

    partial void OnSelectedReportSchoolChanged(School? value)
    {
        if (value == null)
        {
            ReportTitle = "Relatório Global da Rede";
            FrequenciaMedia = "92.5%";
            Bim1Height = 90;
            Bim2Height = 120;
            Bim3Height = 100;
            Bim4Height = 140;
        }
        else
        {
            ReportTitle = $"Relatório: {value.Name}";
            
            // Gerar valores aleatórios para simular a mudança visual por escola
            var rnd = new System.Random(value.Id.GetHashCode());
            FrequenciaMedia = $"{rnd.Next(75, 99)}.{rnd.Next(0, 9)}%";
            Bim1Height = rnd.Next(50, 150);
            Bim2Height = rnd.Next(50, 150);
            Bim3Height = rnd.Next(50, 150);
            Bim4Height = rnd.Next(50, 150);
        }
    }

    [RelayCommand]
    private async Task GeneratePdfReportAsync()
    {
        // Mock generation using Desktop Avalonia Dialog (or just a fake delay)
        System.Console.WriteLine("Gerando PDF demonstrativo...");
        await Task.Delay(1000);
        // Exibiríamos o SaveFileDialog aqui na vida real.
    }

    [RelayCommand]
    private void Logout()
    {
        OnLogout?.Invoke();
    }
}
