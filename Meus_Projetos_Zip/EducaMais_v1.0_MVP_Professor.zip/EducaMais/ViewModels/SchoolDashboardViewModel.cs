using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using EducaMais.Models;
using EducaMais.Services;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace EducaMais.ViewModels;


public partial class ClassSelectionViewModel : ObservableObject
{
    public string ClassId { get; set; } = "";
    public string ClassName { get; set; } = "";
    
    [ObservableProperty]
    private bool _isSelected;
}

public partial class SchoolDashboardViewModel : ViewModelBase
{
    public Action? OnLogout { get; set; }
    public Action<Teacher>? OnAccessTeacher { get; set; }

    [ObservableProperty]
    private string _schoolName = "Escola Municipal Exemplo";

    [ObservableProperty]
    private string _schoolId = "";

    // Abas de navegação
    [ObservableProperty] private bool _isOverviewVisible = true;
    [ObservableProperty] private bool _isTeachersVisible = false;
    [ObservableProperty] private bool _isClassesVisible = false;
    [ObservableProperty] private bool _isStudentsVisible = false;

    // Coleções
    public ObservableCollection<Teacher> Teachers { get; } = new();
    public ObservableCollection<SchoolClass> Classes { get; } = new();
    public ObservableCollection<Student> Students { get; } = new();

    // Indicadores Mockados
    [ObservableProperty] private int _totalTeachers = 0;
    [ObservableProperty] private int _totalClasses = 0;
    [ObservableProperty] private int _totalStudents = 0;
    
    // --- TURMAS (CLASSES) ---
    [ObservableProperty] private bool _isClassModalOpen = false;
    [ObservableProperty] private SchoolClass _editingClass = new();
    public ObservableCollection<string> Shifts { get; } = new() { "Matutino", "Vespertino", "Noturno", "Integral" };

    // --- PROFESSORES ---
    [ObservableProperty] private bool _isTeacherModalOpen = false;
    [ObservableProperty] private Teacher _editingTeacher = new();
    [ObservableProperty] private string _teacherSubjectsInput = "";
    public ObservableCollection<ClassSelectionViewModel> TeacherClassesSelection { get; } = new();

    // --- ALUNOS ---
    [ObservableProperty] private bool _isStudentModalOpen = false;
    [ObservableProperty] private Student _editingStudent = new();
    [ObservableProperty] private SchoolClass? _selectedClassFilter;

    // Navegação
    [RelayCommand]
    private void ShowOverview() { IsOverviewVisible = true; IsTeachersVisible = false; IsClassesVisible = false; IsStudentsVisible = false; }
    
    [RelayCommand]
    private void ShowTeachers() { IsOverviewVisible = false; IsTeachersVisible = true; IsClassesVisible = false; IsStudentsVisible = false; LoadTeachersAsync(); }

    [RelayCommand]
    private void ShowClasses() { IsOverviewVisible = false; IsTeachersVisible = false; IsClassesVisible = true; IsStudentsVisible = false; LoadClassesAsync(); }

    [RelayCommand]
    private void ShowStudents() { IsOverviewVisible = false; IsTeachersVisible = false; IsClassesVisible = false; IsStudentsVisible = true; LoadClassesAsync(); LoadStudentsAsync(); }

    [RelayCommand]
    private void Logout()
    {
        OnLogout?.Invoke();
    }

    partial void OnSchoolIdChanged(string value)
    {
        if (!string.IsNullOrEmpty(value))
        {
            _ = LoadDashboardAsync();
        }
    }

    private async Task LoadDashboardAsync()
    {
        await LoadClassesAsync();
        await LoadTeachersAsync();
        await LoadStudentsAsync();
    }

    // --- LÓGICA TURMAS ---
    private async Task LoadClassesAsync()
    {
        if (string.IsNullOrEmpty(SchoolId)) return;
        try
        {
            var res = await AppwriteService.Instance.RawListDocumentsAsync("classes", new List<string> { $"{{\"method\":\"equal\",\"attribute\":\"school_id\",\"values\":[\"{SchoolId}\"]}}" });
            var docs = res.GetProperty("documents");
            Classes.Clear();
            foreach (var doc in docs.EnumerateArray())
            {
                Classes.Add(JsonSerializer.Deserialize<SchoolClass>(doc.GetRawText(), new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!);
            }
            TotalClasses = Classes.Count;
        }
        catch { }
    }

    [RelayCommand] private void AddClass() { EditingClass = new SchoolClass { SchoolId = SchoolId, Shift = "Matutino" }; IsClassModalOpen = true; }
    [RelayCommand] private void EditClass(SchoolClass sc) { EditingClass = new SchoolClass { Id = sc.Id, Name = sc.Name, Shift = sc.Shift, SchoolId = sc.SchoolId }; IsClassModalOpen = true; }
    [RelayCommand] private void CloseClassModal() { IsClassModalOpen = false; }
    [RelayCommand] private async Task SaveClassAsync()
    {
        var data = new { name = EditingClass.Name, shift = EditingClass.Shift, school_id = SchoolId };
        var json = JsonSerializer.Serialize(data);
        if (string.IsNullOrEmpty(EditingClass.Id))
            await AppwriteService.Instance.RawCreateDocumentAsync("classes", data, new List<string> { "read(\"any\")", "update(\"any\")", "delete(\"any\")" });
        else
            await AppwriteService.Instance.RawUpdateDocumentAsync("classes", EditingClass.Id, data);
        
        IsClassModalOpen = false;
        await LoadClassesAsync();
    }
    [RelayCommand] private async Task DeleteClassAsync(SchoolClass sc)
    {
        try {
            await AppwriteService.Instance.RawDeleteDocumentAsync("classes", sc.Id);
            await LoadClassesAsync();
        } catch (System.Exception ex) {
            System.Console.WriteLine("Erro DeleteClass: " + ex.Message);
        }
    }

    // --- LÓGICA PROFESSORES ---
    private async Task LoadTeachersAsync()
    {
        if (string.IsNullOrEmpty(SchoolId)) return;
        try
        {
            var res = await AppwriteService.Instance.RawListDocumentsAsync("teachers", new List<string> { $"{{\"method\":\"equal\",\"attribute\":\"school_id\",\"values\":[\"{SchoolId}\"]}}" });
            var docs = res.GetProperty("documents");
            Teachers.Clear();
            foreach (var doc in docs.EnumerateArray())
            {
                Teachers.Add(JsonSerializer.Deserialize<Teacher>(doc.GetRawText(), new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!);
            }
            TotalTeachers = Teachers.Count;
        }
        catch { }
    }


    [RelayCommand]
    private void AccessTeacher(Teacher t)
    {
        OnAccessTeacher?.Invoke(t);
    }
    [RelayCommand] private void AddTeacher() 
    { 
        EditingTeacher = new Teacher { SchoolId = SchoolId }; 
        TeacherSubjectsInput = ""; 
        TeacherClassesSelection.Clear();
        foreach (var c in Classes) TeacherClassesSelection.Add(new ClassSelectionViewModel { ClassId = c.Id, ClassName = c.Name, IsSelected = false });
        IsTeacherModalOpen = true; 
    }
    
    [RelayCommand] private void EditTeacher(Teacher t) 
    { 
        EditingTeacher = new Teacher { Id = t.Id, Name = t.Name, Email = t.Email, Phone = t.Phone, SchoolId = t.SchoolId, Subjects = t.Subjects, ClassIds = t.ClassIds }; 
        TeacherSubjectsInput = string.Join(", ", t.Subjects ?? new List<string>()); 
        
        TeacherClassesSelection.Clear();
        foreach (var c in Classes) 
        {
            TeacherClassesSelection.Add(new ClassSelectionViewModel { 
                ClassId = c.Id, 
                ClassName = c.Name, 
                IsSelected = t.ClassIds != null && t.ClassIds.Contains(c.Id) 
            });
        }
        
        IsTeacherModalOpen = true; 
    }
    [RelayCommand] private void CloseTeacherModal() { IsTeacherModalOpen = false; }
    
    [RelayCommand] private async Task SaveTeacherAsync()
    {
        try {
            var input = TeacherSubjectsInput ?? "";
            var subjectsList = input.Split(',').Select(s => s.Trim()).Where(s => !string.IsNullOrEmpty(s)).ToList();
            var selectedClassIds = TeacherClassesSelection.Where(x => x.IsSelected).Select(x => x.ClassId).ToList();
            
            var data = new { name = EditingTeacher.Name, email = EditingTeacher.Email, phone = EditingTeacher.Phone, school_id = SchoolId, subjects = subjectsList, class_ids = selectedClassIds };
            
            if (string.IsNullOrEmpty(EditingTeacher.Id))
                await AppwriteService.Instance.RawCreateDocumentAsync("teachers", data, new List<string> { "read(\"any\")", "update(\"any\")", "delete(\"any\")" });
            else
                await AppwriteService.Instance.RawUpdateDocumentAsync("teachers", EditingTeacher.Id, data);
            
            IsTeacherModalOpen = false;
            await LoadTeachersAsync();
        } catch (System.Exception ex) {
            System.Console.WriteLine("Erro SaveTeacherAsync: " + ex.Message);
        }
    }
    
    [RelayCommand] private async Task DeleteTeacherAsync(Teacher t)
    {
        try {
            await AppwriteService.Instance.RawDeleteDocumentAsync("teachers", t.Id);
            await LoadTeachersAsync();
        } catch (System.Exception ex) {
            System.Console.WriteLine("Erro DeleteTeacher: " + ex.Message);
        }
    }

    // --- LÓGICA ALUNOS ---
    partial void OnSelectedClassFilterChanged(SchoolClass? value)
    {
        _ = LoadStudentsAsync();
    }

    private async Task LoadStudentsAsync()
    {
        if (string.IsNullOrEmpty(SchoolId)) return;
        try
        {
            var queries = new List<string> { $"{{\"method\":\"equal\",\"attribute\":\"school_id\",\"values\":[\"{SchoolId}\"]}}" };
            if (SelectedClassFilter != null)
            {
                queries.Add($"{{\"method\":\"equal\",\"attribute\":\"class_id\",\"values\":[\"{SelectedClassFilter.Id}\"]}}");
            }

            var res = await AppwriteService.Instance.RawListDocumentsAsync("students", queries);
            var docs = res.GetProperty("documents");
            Students.Clear();
            foreach (var doc in docs.EnumerateArray())
            {
                Students.Add(JsonSerializer.Deserialize<Student>(doc.GetRawText(), new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!);
            }
            if (SelectedClassFilter == null) TotalStudents = Students.Count; // Atualiza indicador geral só quando não filtra
        }
        catch { }
    }

    [RelayCommand] private void AddStudent() { EditingStudent = new Student { SchoolId = SchoolId, ClassId = SelectedClassFilter?.Id ?? "" }; IsStudentModalOpen = true; }
    [RelayCommand] private void EditStudent(Student s) { EditingStudent = new Student { Id = s.Id, Name = s.Name, Registration = s.Registration, ClassId = s.ClassId, SchoolId = s.SchoolId }; IsStudentModalOpen = true; }
    [RelayCommand] private void CloseStudentModal() { IsStudentModalOpen = false; }
    [RelayCommand] private async Task SaveStudentAsync()
    {
        var data = new { name = EditingStudent.Name, registration = EditingStudent.Registration, class_id = EditingStudent.ClassId, school_id = SchoolId };
        var json = JsonSerializer.Serialize(data);
        if (string.IsNullOrEmpty(EditingStudent.Id))
            await AppwriteService.Instance.RawCreateDocumentAsync("students", data, new List<string> { "read(\"any\")", "update(\"any\")", "delete(\"any\")" });
        else
            await AppwriteService.Instance.RawUpdateDocumentAsync("students", EditingStudent.Id, data);
        
        IsStudentModalOpen = false;
        await LoadStudentsAsync();
    }
    [RelayCommand] private async Task DeleteStudentAsync(Student s)
    {
        try {
            await AppwriteService.Instance.RawDeleteDocumentAsync("students", s.Id);
            await LoadStudentsAsync();
        } catch (System.Exception ex) {
            System.Console.WriteLine("Erro DeleteStudent: " + ex.Message);
        }
    }

    [RelayCommand] private async Task ImportCsvAsync()
    {
        try {
            // Mock import (simulate delay)
            await Task.Delay(1500);
            
            // Simular a criação de alunos genéricos
            if (SelectedClassFilter != null)
            {
                var data1 = new { name = "Joãozinho Silva (Importado)", registration = "MAT-" + new System.Random().Next(1000, 9999), class_id = SelectedClassFilter.Id, school_id = SchoolId };
                await AppwriteService.Instance.RawCreateDocumentAsync("students", data1, new List<string> { "read(\"any\")", "update(\"any\")", "delete(\"any\")" });
                var data2 = new { name = "Mariazinha Souza (Importada)", registration = "MAT-" + new System.Random().Next(1000, 9999), class_id = SelectedClassFilter.Id, school_id = SchoolId };
                await AppwriteService.Instance.RawCreateDocumentAsync("students", data2, new List<string> { "read(\"any\")", "update(\"any\")", "delete(\"any\")" });
                
                await LoadStudentsAsync();
            }
        } catch (System.Exception ex) {
            System.Console.WriteLine("Erro ImportCsvAsync: " + ex.Message);
        }
    }
}
