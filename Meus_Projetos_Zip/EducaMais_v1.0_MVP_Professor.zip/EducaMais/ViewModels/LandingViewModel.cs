using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;

namespace EducaMais.ViewModels;

public partial class LandingViewModel : ViewModelBase
{
    public Action<string>? OnProfileSelected { get; set; }

    [RelayCommand]
    private void SelectProfile(string profile)
    {
        OnProfileSelected?.Invoke(profile);
    }
}
